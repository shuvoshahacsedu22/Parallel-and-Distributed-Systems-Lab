#!/bin/sh
rm -r *.class
javac *.java
rmic RegistrationServer
rmiregistry 5000

