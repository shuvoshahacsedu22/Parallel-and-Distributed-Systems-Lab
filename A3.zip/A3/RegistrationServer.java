import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.util.*;
import java.io.IOException;



public class RegistrationServer extends UnicastRemoteObject implements RegistrationInterface{
	private static HashMap<String, Course> courses = new HashMap<String, Course>();
	private static HashMap<String, Student> students = new HashMap<String, Student>();
	private final static Object lockA = new Object();
	private final static String filePath = "/home/shuvo/Desktop/CODE/ds-lab/A3/StudentDatabase/";
	final static File folder = new File(filePath);

	protected RegistrationServer() throws RemoteException,FileNotFoundException {
		super();
		initializeList();
	}

	public boolean register(String studentID, String courseID) throws RemoteException {
		int coCount=0;
		if (students.containsKey(studentID) == false) {
			throw new StudentNotExistsException("Student doesn't exist!");
		}
		if (courses.containsKey(courseID) == false) {
			throw new CourseNotExistsException("Course doesn't exist!");
		}

		Set<String> pre = courses.get(courseID).getPreRequisite();
		Set<String> co = courses.get(courseID).getCoRequisite();

		for (String c : pre) {
			if (students.get(studentID).hasCourse(c) == false) {
				throw new PrerequisiteCourseException("Pre-requisite course not taken!");
			}
		}
		for (String c : co) {
			if (students.get(studentID).hasCourse(c) == true) {
				coCount++;
			}
			
			Set<String> preOfCo = courses.get(c).getPreRequisite();	
			for(String k:preOfCo){
				if(students.get(studentID).hasCourse(k) == false)
					throw new PrerequisiteCourseException("Pre-requisite course of Co-requisite course not taken!");
			}
			
			
		}

		if (students.get(studentID).hasCourse(courseID) == true) {
			throw new AlreadyRegisteredCourseException("Already registered in the course!");
		}
		if (students.get(studentID).totalCourse() >= 3 || students.get(studentID).totalCourse() + co.size() - coCount >= 3) {
			throw new TakenTooManyCourseException("Maximum Course Taken!");
		}
		synchronized (lockA) {// synchronized block for concurrency

			for (String c : co) {
				if (students.get(studentID).hasCourse(c) == false && courses.get(c).getCapacity() <= 0) {
					throw new CourseFullException("Course capacity is full!");
				}
			}
			if (courses.get(courseID).getCapacity() <= 0) {
				throw new CourseFullException("Course capacity is full!");
			}

			students.get(studentID).addCourse(courseID);
			courses.get(courseID).setCapacity(courses.get(courseID).getCapacity() - 1);

			for (String c : co) {
				students.get(studentID).addCourse(c);
				courses.get(c).setCapacity(courses.get(c).getCapacity() - 1);
			}
		}
		try {
			FileWriter fw = new FileWriter(filePath + studentID);
			Set<String> st = students.get(studentID).getCourses();
			String temp = "";
			for (String c : st)
				temp += (c + "\n");
			fw.write(temp);
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return true;
	}

	public boolean unregister(String studentID, String courseID) throws RemoteException {
		if (students.containsKey(studentID) == false) {
			throw new StudentNotExistsException("Student doesn't exist!");
		} else if (courses.containsKey(courseID) == false) {
			throw new CourseNotExistsException("Course doesn't exist!");
		}

		Set<String> pre = courses.get(courseID).getPreRequisite();
		Set<String> co = courses.get(courseID).getCoRequisite();
		boolean flag1 = true;
		boolean flag2 = true;
		if (students.get(studentID).hasCourse(courseID) == false) {
			throw new NotRegisteredException("Not registered in the course!");
		}
		synchronized (lockA) {

			for (String c : pre) {
				students.get(studentID).removeCourse(c);
				courses.get(c).setCapacity(courses.get(c).getCapacity() + 1);
			}
			for (String c : co) {
				students.get(studentID).removeCourse(c);
				courses.get(c).setCapacity(courses.get(c).getCapacity() + 1);
			}

			students.get(studentID).removeCourse(courseID);
			courses.get(courseID).setCapacity(courses.get(courseID).getCapacity() + 1);

		}

		try {
			FileWriter fw = new FileWriter(filePath + studentID);
			Set<String> st = students.get(studentID).getCourses();
			String temp = "";
			for (String c : st)
				temp += (c + "\n");
			fw.write(temp);
			System.out.println("Written");
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return true;
	}

	public Set<String> getRegistrationList(String studentID) throws RemoteException {
		if (students.containsKey(studentID) == false)
			throw new StudentNotExistsException("");
		return students.get(studentID).getCourses();
	}

	private static void initializeList() throws FileNotFoundException {
		
		courses.put("CSE 1102", new Course("CSE 1102", new HashSet<>(Arrays.asList("CSE 1101")),
				new HashSet<>(Arrays.asList()), 5));
		courses.put("CSE 1101", new Course("CSE 1101", new HashSet<>(Arrays.asList()),
				new HashSet<>(Arrays.asList()), 5));
		courses.put("CSE 1201", new Course("CSE 1201", new HashSet<>(Arrays.asList()),
				new HashSet<>(Arrays.asList("CSE 1102")), 5));
		courses.put("CSE 2101",
				new Course("CSE 2101", new HashSet<>(Arrays.asList("CSE 1201")), new HashSet<>(Arrays.asList()), 5));
		courses.put("CSE 2202",
				new Course("CSE 2202", new HashSet<>(Arrays.asList("CSE 2101")), new HashSet<>(Arrays.asList()), 3));
		courses.put("CSE 3101", new Course("CSE 3101", new HashSet<>(Arrays.asList("CSE 2203")),
				new HashSet<>(Arrays.asList("CSE 2204")), 3));
		courses.put("STAT 3205",
				new Course("STAT 3205", new HashSet<>(Arrays.asList()), new HashSet<>(Arrays.asList()), 2));
		courses.put("CSE 2203",
				new Course("CSE 2203", new HashSet<>(Arrays.asList()), new HashSet<>(Arrays.asList()), 2));
		courses.put("CSE 2204",
				new Course("CSE 2204", new HashSet<>(Arrays.asList()), new HashSet<>(Arrays.asList()), 2));
		courses.put("CSE 4101",
				new Course("CSE 4101", new HashSet<>(Arrays.asList()), new HashSet<>(Arrays.asList("CSE 1101")), 2));		
		

		File file;
		Scanner sc;
		for (final File fileEntry : folder.listFiles()) {
			// System.out.println(fileEntry.getName());
			String studentID = fileEntry.getName();

			try {
				file = new File(filePath + studentID);
				System.out.println(studentID);
				sc = new Scanner(file);
				Student st = new Student(studentID);
				//System.out.println(studentID);
				String cID="";				
				while (sc.hasNextLine()) {
					// System.out.println(sc.nextLine());
					cID=sc.nextLine();
					courses.get(cID).setCapacity( courses.get(cID).getCapacity() - 1 ); 			
					st.addCourse(cID);

				}
				students.put(studentID, st);
				sc.close();
			} catch (FileNotFoundException ex) {
				System.out.print(ex);
			}

		}
	}
}
