import java.rmi.*;
public class TakenTooManyCourseException extends RemoteException{
	public TakenTooManyCourseException(String str){
		super(str);	
	}
}
