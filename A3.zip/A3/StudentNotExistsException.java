import java.rmi.*;
public class StudentNotExistsException extends RemoteException{
	public StudentNotExistsException(String str){
		super(str);	
	}
}
