import java.rmi.*;
public class CourseFullException extends RemoteException{
	public CourseFullException(String str){
		super(str);	
	}
}
