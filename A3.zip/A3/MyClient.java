import java.rmi.*;
import java.util.*;

public class MyClient {
	public static void main(String args[]) throws Exception {
		try {
			RegistrationInterface stub = (RegistrationInterface) Naming.lookup("rmi://localhost:5000/temp");
		
		System.out.println("1.Register a Course\n2.Unregister a Course\n3.Get Registered Courses\n4.Close connection");
		while(true) {
			Scanner sc = new Scanner(System.in);
			int i = sc.nextInt();
			if(i==1) {
				System.out.println("Your ID?");
				String studentID=sc.next();
				System.out.println("Course ID you want to register for?");
				String courseID=sc.next();
				courseID = courseID+" "+sc.next();
				try {
				if(stub.register(studentID,courseID)==true)
				System.out.println("Registration Succesful!");
				}
				catch(Exception e){
					System.out.println(e.getMessage());
				}
			}
			else if(i==2) {
				System.out.println("Your ID?");
				String studentID=sc.next();
				System.out.println("Course ID you want to unregister for?");
				String courseID=sc.next();
				courseID = courseID+" "+sc.next();
				try {
				if(stub.unregister(studentID,courseID)==true)
					System.out.println("Unregistration Succesful!");
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
				
			}
			else if(i==3){
				System.out.println("Your ID?");
				String studentID=sc.next();
				try {
				Set<String> st=stub.getRegistrationList(studentID);
				for(String s:st) {
					System.out.println(s);
				}
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
			else {
				break;
			}
			
			
		}
		} catch (Exception e) {
		}
	}

}
