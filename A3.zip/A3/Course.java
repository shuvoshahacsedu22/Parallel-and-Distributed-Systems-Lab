import java.util.*;
class Course{
	private String id;
	private Set<String> preRequisite;
	private Set<String> coRequisite;
	private int capacity;
	public Course(String id, Set<String> preRequisite, Set<String> coRequisite, int capacity) {
		// TODO Auto-generated constructor stub
		setCapacity(capacity);
		setCoRequisite(coRequisite);
		setId(id);
 		setPreRequisite(preRequisite);
	}
    public int getCapacity() {
		return capacity;
	}
	public Set<String> getCoRequisite() {
		return coRequisite;
	}
	public String getId() {
		return id;
	}
	public Set<String> getPreRequisite() {
		return preRequisite;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public void setCoRequisite(Set<String> coRequisite) {
		this.coRequisite = coRequisite;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setPreRequisite(Set<String> preRequisite) {
		this.preRequisite = preRequisite;
	}
}