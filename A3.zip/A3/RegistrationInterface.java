import java.rmi.*;
import java.rmi.Remote; 
import java.rmi.RemoteException;  
import java.util.*;
import java.rmi.server.*;
// Creating Remote interface for our application 
public interface RegistrationInterface extends Remote {  
   public boolean register(String studentID,String courseID) throws RemoteException;  
   public boolean unregister(String studentID,String courseID) throws RemoteException;
   public Set<String> getRegistrationList(String studentID) throws RemoteException;	
} 
