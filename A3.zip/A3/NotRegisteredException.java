import java.rmi.*;
public class NotRegisteredException extends RemoteException{
	public NotRegisteredException(String str){
		super(str);	
	}
}
