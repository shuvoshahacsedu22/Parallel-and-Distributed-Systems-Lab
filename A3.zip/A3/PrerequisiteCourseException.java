import java.rmi.*;
public class PrerequisiteCourseException extends RemoteException{
	public PrerequisiteCourseException(String str){
		super(str);		
	}
}
