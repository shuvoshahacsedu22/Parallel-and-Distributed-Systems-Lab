import java.rmi.*;
public class AlreadyRegisteredCourseException extends RemoteException{
	public AlreadyRegisteredCourseException(String str){
		super(str);	
	}
}
