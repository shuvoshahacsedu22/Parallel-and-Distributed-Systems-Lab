import java.util.*;
class Student{
	private String id;
	private Set<String> courseTaken;
	public Student(String id) {
		// TODO Auto-generated constructor stub
		setId(id);
		courseTaken= new HashSet<String>();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id=id;
	}
	public void addCourse(String courseName) {
		courseTaken.add(courseName);
	}
	public void removeCourse(String courseName) {
		courseTaken.remove(courseName);
	}
	public boolean hasCourse(String courseName) {
		return courseTaken.contains(courseName);
	}
	public int totalCourse() {
		return courseTaken.size();
	}
	public Set<String> getCourses(){
		return courseTaken;
	}
	
}