import java.rmi.*;
public class CourseNotExistsException extends RemoteException{
	public CourseNotExistsException(String str){
		super(str);	
	}
}
