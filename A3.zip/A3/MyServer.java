    import java.rmi.*;  
    import java.rmi.registry.*;  
    import java.util.*;
    public class MyServer{ 
    public static void main(String args[]){  
    try{  
    RegistrationInterface stub=new RegistrationServer();  
    Naming.rebind("rmi://localhost:5000/temp",stub);  
    }catch(Exception e){System.out.println(e);}  
    }  
    }  
