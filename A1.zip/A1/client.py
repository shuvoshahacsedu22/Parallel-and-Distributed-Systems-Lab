# Import socket module
import socket

def Main():
    # local host IP '127.0.0.1'
	host = '172.16.5.196'

    # Define the port on which you want to connect
	port = 12345

	s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    # connect to server on local computer
	s.connect((host,port))

    # message you send to server
	while True:
		datam = s.recv(1024)
		data = str(datam.decode('utf-8'))
		print('Server :',data)
		if data == 'I have no more jokes to tell.':
			break
        # message sent to server
		while True:
			message = input()
			t=len(message)
			#print(t)
			if(t!=0):
				break
		s.send(message.encode('utf-8'))
		if message == 'N' or message == 'n':
			break
		# ask the client whether he wants to continue
		# close the connection
	
	s.close()
	

if __name__ == '__main__':
    Main()

