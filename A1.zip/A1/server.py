# import socket programming library
import socket
import random 
import os
# import thread module
from _thread import *
import threading
shared_int=0
w,h=3,30
s=None
Matrix = [["" for x in range(w)] for y in range(h)]
lock = threading.Lock()

# thread fuction
def threaded(c,addr):
	global s
	global shared_int
	#print(Matrix)
	flag=0
	n=[x for x in range(30)]
	random.shuffle(n)
	cnt=0
	while True:
		data='Knock Knock!'
		c.send(data.encode('utf-8'))
		while True:
			datam = c.recv(1024)
			data=str(datam.decode('utf-8'))
			if data.upper() != 'Who\'s there?'.upper():
				data='You are supposed to say, “Who\'s there?”. Let\'s try again.\nServer : '
				c.send(data.encode('utf-8'))
				break
			data = Matrix[n[cnt]][0]
			data = data.rstrip()
			c.send(data.encode('utf-8'))
			datam = c.recv(1024)
			data = str(datam.decode('utf-8'))
			temp=Matrix[n[cnt]][1]
			t=temp
			temp = temp.rstrip()
			temp = temp.upper()
			data = data.upper()
			if data!= temp:
				data = 'You are supposed to say,"' +t+ '". Let\'s try again.\nServer : '
				c.send(data.encode('utf-8'))
				break
			data = Matrix[n[cnt]][2]
			data=data.rstrip()
			c.send(data.encode('utf-8'))
			data = 'Would you like to listen to another? (Y/N)'
			c.send(data.encode('utf-8'))
			datam = c.recv(1024)
			data = str(datam.decode('utf-8'))
			if data == 'Y' or data =='y':
				cnt=cnt+1
				if cnt==3:
					data='I have no more jokes to tell.'
					c.send(data.encode('utf-8'))
					flag=1
				break
			elif data == 'N' or data=='n':
				flag=1
				break
			else:
				data = 'You are supposed to say, (Y/N). Let\'s try again.\nServer : '
				c.send(data.encode('utf-8'))
				break
		if flag==1:
			break
	print('Closing connection to :', addr[0], ':', addr[1])
	c.close()
	with lock:
		shared_int=shared_int-1
		if shared_int==0:
			os._exit(1)

			
def readFile(filename):
	f = open(filename,"r")
	jokes = f.readlines()
	f.close()
	cnt=0
	i,j=0,0
	for st in jokes:
		Matrix[i][j]=st
		cnt=cnt+1
		if cnt%3==0:
			i=i+1
		j=j+1
		j=j%3
		i=i%30
		
def Main():
	global s
	global shared_int
	host = ""
	filename="in.txt"
	readFile(filename)
	# reverse a port on your computer
	# in our case it is 12345 but it
	# can be anything
	port = 12345
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind((host, port))
	print("socket binded to port", port)
    # put the socket into listening mode
	s.listen(5)
	print("socket is listening")
    # a forever loop until client wants to exit
	while True:
        # establish connection with client	
		c, addr = s.accept()
		with lock:
			shared_int=shared_int+1
        # lock acquired by client
        # print_lock.acquire()
		print('Connected to :', addr[0], ':', addr[1])

        # Start a new thread and return its identifier
		start_new_thread(threaded, (c,addr))
	s.close()
if __name__ == '__main__':
    Main()

